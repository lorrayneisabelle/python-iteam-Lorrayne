# python-iteam-Lorrayne Isabelle Paz de Oliveira


Repositório de atividades do **Módulo 07 — Programação em Python**  
Instituto Tecnológico Educacional da Amazônia — ITEAM  
Curso: Capacitação em Desenvolvimento Full Stack | 2026 - Vespertino

---

## Identificação

| Campo | Preenchimento |
|---|---|
| **Nome completo** | Lorrayne Isabelle Paz de Oliveira |
| **Turma** | Vespertino 2026 |
| **E-mail** | Lorrayne Isabelle Paz de Oliveiraxerfan@gmail.com |
| **GitHub** | @Lorrayne Isabelle Paz de Oliveiradbatista |

---

## Estrutura do Repositório

```
python-iteam-SEUNOME/
├── desafios/
│   ├── desafio-01/   ← Aula 01: Seu Primeiro Script
│   ├── desafio-02/   ← Aula 02: Calculadora de IMC
│   ├── desafio-03/   ← Aula 03: Sistema de Multas
│   ├── desafio-04/   ← Aula 04: Tabuada Personalizada
│   ├── desafio-05/   ← Aula 05: Gerenciador de Compras
│   ├── desafio-06/   ← Aula 06: Bio-Cadastro
│   ├── desafio-07/   ← Aula 07: Bio-Calculadora
│   ├── desafio-08/   ← Aula 08: Banco Digital
│   ├── desafio-09/   ← Aula 09: Sistema de Frota
│   └── desafio-10/   ← Aula 10: Projeto Final
├── listas/
│   ├── lista-01/     ← Lista de Consolidação 1 (Aulas 01–04)
│   └── lista-02/     ← Lista de Consolidação 2 (Aulas 06–09)
└── projeto-integrador/  ← Projeto Final: Urna Eletrônica
```

**Aprovação:** Média ≥ 7,0 + Frequência ≥ 75%

---

*Boa Vista, RR — ITEAM 2026*
