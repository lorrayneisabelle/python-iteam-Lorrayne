# Desafio 04 — Tabuada Personalizada
# Aluno: Lorrayne Isabelle Paz de Oliveira
# Data:  22/05/2026 

# ── Escreva sua solução abaixo ──────────────────────────────────────────────

while True:
    numero = int(input("Digite um número de 1 a 10 (ou 0 para sair): "))

    # Verifica se o usuário deseja sair
    if numero == 0:
        print("Você escolheu sair.")
        break

    if numero < 1 or numero > 10:
        print("Digite um número entre 1 e 10.\n")
        continue

    print(f"\nTabuada do {numero}:")

    for i in range(1, 11):
        print(f"{numero} x {i} = {numero * i}")

    print()  # linha em branco