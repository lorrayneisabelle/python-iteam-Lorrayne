# Explicação — Desafio 04 — Tabuada Personalizada

**Aluno:** Lorrayne Isabelle Paz de Oliveira
**Data:** 22/05/2025

---

## O que meu programa faz

Lê um número informado pelo usuário entre 1 e 10 e mostra a tabuada, enqaunto o usuário nao pedir para sair digitando 0

---

## Resposta à Pergunta Obrigatória

> Para esse exercício, por que `for` com `range()` é preferível ao `while`? Em que cenário o `while` seria a escolha certa?

O while é usado sempre que não sabemos quantas vezes o programa vai rodar. 
No caso, nao sabemos quantas tabuadas ele vai querer até sair

---

## Dificuldades encontradas

N/A