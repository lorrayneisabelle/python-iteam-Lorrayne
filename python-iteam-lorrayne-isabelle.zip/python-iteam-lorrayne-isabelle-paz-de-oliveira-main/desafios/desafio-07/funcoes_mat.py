

#Função para calcular área do Círculo
def area_circulo(raio):
    pi = 3.14159
    area = pi * (raio ** 2)
    return area


#Volume da Esfera
def volume_esfera(raio):    
    pi = 3.14159
    volume = (4/3) * pi * (raio ** 3)
    return volume

#Hipotenusa (com docstring)
def hipotenusa(lado1, lado2):
    return (lado1 ** 2 + lado2 ** 2) ** 0.5