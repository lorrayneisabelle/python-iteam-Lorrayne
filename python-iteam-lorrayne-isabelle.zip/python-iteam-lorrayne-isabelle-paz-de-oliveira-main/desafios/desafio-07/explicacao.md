# Explicação — Desafio 07 — Bio-Calculadora

**Aluno:** Lorrayne Isabelle Paz de Oliveira   
**Data:** 25/05/2026

---

## O que meu programa faz

É uma calculadora que calcula de acordo com o escolhido pelo usuário a área de um circulo, volume de uma esfera ou a hipotenusa, usando funções pre existentes em outro modulo, chamadas via importação.

---

## Resposta à Pergunta Obrigatória

> Por que separar as funções em um arquivo diferente do `solucao.py`? O que muda no projeto quando você tem 50 funções em vez de 3?

As funções são separadas para melhor performance, reaproveitamento de código, melhor organização e manutenção do código.

---

## Dificuldades encontradas

N/A
