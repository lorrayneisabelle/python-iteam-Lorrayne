# Desafio 07 — Bio-Calculadora
# Aluno: Lorrayne Isabelle Paz de Oliveira
# Data:  25/05/2026

# ── Escreva sua solução abaixo ──────────────────────────────────────────────
#Crie um sistema modularizado com **dois arquivos**:
#1. `funcoes_mat.py` — Funções para: Área do Círculo, Volume de Esfera e Hipotenusa (com docstrings).
#2. `solucao.py` (main) — O usuário escolhe o cálculo e o programa importa a função correspondente.

def main(): 
    print("Bio-Calculadora!")
    print("Escolha o cálculo que deseja realizar:")
    print("1. Área do Círculo")
    print("2. Volume da Esfera")
    print("3. Hipotenusa de um Triângulo Retângulo")

    escolha = input("Digite o número da opção desejada: ")

    

    if escolha == '1':
        #importando a função para calcular a área do círculo
        from funcoes_mat import area_circulo

        raio = float(input("Digite o raio do círculo: "))
        area = area_circulo(raio)
        print(f"A área do círculo é: {area:.2f}")
    
    elif escolha == '2':
        #importando a função para calcular o volume da esfera
        from funcoes_mat import volume_esfera

        raio = float(input("Digite o raio da esfera: "))
        volume = volume_esfera(raio)
        print(f"O volume da esfera é: {volume:.2f}")
    
    elif escolha == '3':
        #importando a função para calcular a hipotenusa
        from funcoes_mat import hipotenusa

        lado1 = float(input("Digite o comprimento do primeiro lado: "))
        lado2 = float(input("Digite o comprimento do segundo lado: "))
        hipotenusa_resultado = hipotenusa(lado1, lado2)
        print(f"A hipotenusa do triângulo retângulo é: {hipotenusa_resultado:.2f}")
    
    else:
        print("Opção inválida. Por favor, escolha uma opção válida.")



main()