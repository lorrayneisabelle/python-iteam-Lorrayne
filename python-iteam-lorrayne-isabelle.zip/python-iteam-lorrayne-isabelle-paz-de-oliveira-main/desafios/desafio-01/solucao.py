# Desafio 01 — Seu Primeiro Script
# Aluno: Lorrayne Isabelle Paz de Oliveira
# Data:  20/05/2026

# ── Escreva sua solução abaixo ──────────────────────────────────────────────


nome = str(input("Digite seu nome: "))
dn = int(input("Digite o ano de nascimento: "))
ano_atual = 2026

idade = ano_atual - dn


hobbies = input("Digite seus hobbies (separados por vírgula): ")
hobbies_lista = hobbies.split(",")
print("Olá, ", nome, "! Sua idade é: ", idade, "anos.")
print("Seus hobbies são: ", hobbies_lista)

