# Explicação — Desafio 01

**Aluno:**  Lorrayne Isabelle Paz de Oliveira  
**Data:** 18/05/2025

---

## O que meu programa faz

O programa recebe o nome e data de nascimento da pessoa em variáveis, e calcula com base no valor do ano autal, que é uma constante, a idade da pessoa;
Depois lê os hobbies da pessoa, separados por vírgula;
Ao final, mostra(lista) nome, idade e os hobbies da pessoa

---

## Resposta à Pergunta Obrigatória

> Por que é necessário converter o resultado do `input()` antes de calcular a idade? O que acontece se não converter?


Caso nao faça a conversão, a resposta é salva como string e não é possivel fazer o calculo da idade, ao conerter o número é gravado como numero e a conta é viável

---

## Dificuldades encontradas

N/A
