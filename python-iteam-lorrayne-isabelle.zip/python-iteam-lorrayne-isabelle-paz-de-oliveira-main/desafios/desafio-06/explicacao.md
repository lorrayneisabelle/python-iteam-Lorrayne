# Explicação — Desafio 06 — Bio-Cadastro

**Aluno:** Lorrayne Isabelle Paz de Oliveira
**Data:** 25/05/2026

---

## O que meu programa faz

É um programa que recebe nome e cargo de cada funcionário, até o usuário escolher sair.
Para cada nome e cargo inserido, essas informações são gravadas num dicionário de colaborador, e esse dicionário inserido na lista de funcionários. No final, para cada funcionário da lista são exibidos os dados dele, que são nome e cargo.

---

## Resposta à Pergunta Obrigatória

> Por que usamos um **dicionário** para cada funcionário e não uma lista com dois itens como `["Ricardo", "Dev"]`? Qual é a desvantagem de `funcionario[0]` comparado a `funcionario["nome"]`?

Usamos dicionário pois pra cada funcionário existem mais de um atributo e com lista não seria possível fazer isso pra mais de  aluno no mesmo item, teriamos que criar uma lista para cada aluno, e ficaria inviável pois além de tudo não é sabido anteriormente a quantidade de alunos.

---

## Dificuldades encontradas

N/A
