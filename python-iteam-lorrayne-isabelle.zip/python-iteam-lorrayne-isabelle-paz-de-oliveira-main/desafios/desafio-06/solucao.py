# Desafio 06 — Bio-Cadastro
# Aluno: Lorrayne Isabelle Paz de Oliveira 
# Data:  25/05/2026

# ── Escreva sua solução abaixo ──────────────────────────────────────────────
#Crie um script `solucao.py` que:
#1. Comece com uma lista vazia chamada `equipe`.
#2. Em um laço `while`, peça `nome` e `cargo` de um colaborador.
#3. Salve esses dados em um dicionário e adicione à lista `equipe`.
#4. Ao digitar "sair", percorra a lista e imprima: `"Funcionário: {nome} | Cargo: {cargo}"`.

#lista de equipe vazia
equipe = []

while True:
    nome = input("Digite o nome do colaborador (ou 'sair' para encerrar): ")

    #verifica se o usuário deseja sair
    if nome.lower() == "sair":
        break
    cargo = input("Digite o cargo do colaborador: ")
    print() #pula linha 

    #Cria um dicionário que recebe os dados recebidos
    colaborador = {"nome": nome, "cargo": cargo}
    equipe.append(colaborador)

print("\nColaboradores cadastrados:")
for colaborador in equipe:
    print(f"Funcionário: {colaborador['nome']} | Cargo: {colaborador['cargo']}")

