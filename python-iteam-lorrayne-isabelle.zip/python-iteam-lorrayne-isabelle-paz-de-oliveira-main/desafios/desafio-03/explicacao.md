# Explicação — Desafio 03 — Sistema de Multas

**Aluno:** Lorrayne Isabelle Paz de Oliveira
**Data:** 20/05/2026

---

## O que meu programa faz

Recebe a velocidade média do carro e aplica multa de 7 reais por km excedido  quando a velocidade é maior que 80km/h; Se tiver dentro da velocidade deseja boa viagem.

---

## Resposta à Pergunta Obrigatória

> Por que usamos `elif` e não múltiplos `if` separados? Dê um exemplo concreto onde a diferença causaria um resultado errado.

Para tratar outras possibilidades além de a pessoa receber multa; Somente com if, se a pessoa digitasse valor negativo ou 0, por exemplo, nao seria tratado, cairia apenas desejando boa viagem como se tivesse em uma velocidade adequada ;

---

## Dificuldades encontradas

N/A
