# Desafio 03 — Sistema de Multas
# Aluno: Lorrayne Isabelle Paz de Oliveira
# Data:  20/05/2026

# ── Escreva sua solução abaixo ──────────────────────────────────────────────
    
velocidade = float(input("Digite a velocidade atual do carro (km/h): "))

if velocidade > 80:
    excesso = velocidade - 80
    multa = excesso * 7
    print("Multado! Você excedeu o limite de 80km/h")
    print(f"Valor da multa: R$ {multa:.2f}")
elif velocidade <= 80 and velocidade > 0:
    print("Boa viagem! Dirija com segurança")
else:
    print("Velocidade inválida. Por favor, insira um valor positivo.")

