# Explicação — Desafio 05 — Gerenciador de Compras

**Aluno:** Lorrayne Isabelle Paz de Oliveira
**Data:** 22/05/2026

---

## O que meu programa faz

Lê uma lista de itens até que o usuário escolha sair, e depois exibe a lista digitada com a quantidade de itens contidos nela

---

## Resposta à Pergunta Obrigatória

> Por que usamos uma **lista** e não uma **tupla** para essa lista de compras? O que mudaria no comportamento do programa se tentássemos usar tupla?

Temos que usar lista pois a tupla é imutavel, então como está sempre mudando quando o usuário adiciona um item, tem que ser lista;

---

## Dificuldades encontradas

N/A
