# Desafio 05 — Gerenciador de Compras
# Aluno: Lorrayne Isabelle Paz de Oliveira
# Data:  22/05/2026

# ── Escreva sua solução abaixo ──────────────────────────────────────────────



produtos = []

while True:
    produto = input("Digite o nome do produto (ou 'fim' para encerrar): ")

    if produto.lower() == "fim":
        break

    produtos.append(produto)

print("\nLista de produtos:")

for produto in produtos:
    print(f"Item {produtos.index(produto) + 1}: {produto}")

print(f"\nTotal de itens: {len(produtos)}")
