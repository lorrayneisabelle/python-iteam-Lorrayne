# Explicação — Desafio 02 — Calculadora de IMC

**Aluno:** Lorrayne Isabelle Paz de Oliveira   
**Data:** 19/05/2026

---

## O que meu programa faz

O programa recebe o nome e as informações de peso e altura e calcula o IMC;

---

## Resposta à Pergunta Obrigatória

> Por que é necessário usar `float()` ao capturar peso e altura com `input()`? O que aconteceria se usássemos `int()` para a altura `1.75`?

Temos que usar float por conta de peso e altura serem números deciais, ou seja, com numeros após a virgula , e por conta da divisão;
Não usando o sistema retornar erro de valor ao tentar entrar com um numero com decimal em tipo inteiro, por exemplo, tentei colocar 1.45 no peso e retornou um erro com final assim:     peso = int(input("Digite seu peso em kg: "))
ValueError: invalid literal for int() with base 10: '1.45'

---

## Dificuldades encontradas

N/A
