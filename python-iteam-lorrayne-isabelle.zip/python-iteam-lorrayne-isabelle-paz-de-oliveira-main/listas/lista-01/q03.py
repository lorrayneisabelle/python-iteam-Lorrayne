# Lista 01 — Questão 03: Ficha de Cadastro
# Aluno: Lorrayne Isabelle Paz de Oliveira
# Data:  22/05/2026

# ── Enunciado ───────────────────────────────────────────────────────────────
# Solicite: nome completo, CPF (str), ano de nascimento (int), altura (float).
# O programa deve:
#   1. Calcular e exibir a idade em 2026.
#   2. Exibir todos os dados com f-string e tipos corretos.
#   3. Tratar com try/except o caso em que o ano não seja um número.
# Explique em comentário: por que float para altura e não int?

# ── Sua solução abaixo ──────────────────────────────────────────────────────

nome = input("Digite seu nome completo: ")
cpf = input("Digite seu CPF: ")

# Tentando receber valores corretos, senao for o esperado vai exibir uma mensagem de erro
try:
    # Ano de nascimento deve ser int pois é um número inteiro sem casas decimais
    ano_nascimento = int(input("Digite o ano de nascimento: "))

    #Altura deve ser float pois pode ter casas decimais para ser exata
    altura = float(input("Digite sua altura em metros: "))

# Exibe erro caso o ano de nascimento ou a altura não sejam números válidos
except ValueError:
    print("Erro: Por favor, insira valores numéricos válidos.")

#
else:
    idade = 2026 - ano_nascimento

print(f"Nome: {nome}")
print(f"CPF: {cpf}")
print(f"Idade em 2026: {idade} anos")
print(f"Altura: {altura} metros")
