# Lista 01 — Questão 09: EAFP vs LBYL
# Aluno: Lorrayne Isabelle Paz de Oliveira
# Data:  22/05/2026

# ── Enunciado ───────────────────────────────────────────────────────────────
# Em q09.py: reescreva a função abaixo no estilo EAFP usando try/except.
# 
#   def dividir(a, b):
#       if b != 0:
#           return a / b
#       else:
#           return None
# 
# Em q09_resposta.txt: explique o que significa EAFP e qual versão é mais Pythônica.

# ── Sua solução abaixo ──────────────────────────────────────────────────────



#EAFP , de forma simples é tentar tratar os erros do que tentar tratar cada possibilidade;
#A versão com try/except é mais Pythônica pois tende a ser mais direta;


def dividir(a, b):
    try:
        return a / b
    except ZeroDivisionError:
        return None

