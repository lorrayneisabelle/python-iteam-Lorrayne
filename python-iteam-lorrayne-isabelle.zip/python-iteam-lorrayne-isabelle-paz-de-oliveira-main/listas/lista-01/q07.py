# Lista 01 — Questão 07: Progressão e Análise
# Aluno: Lorrayne Isabelle Paz de Oliveira
# Data:  22/05/2026

# ── Enunciado ───────────────────────────────────────────────────────────────
# Leia 10 notas (0.0–10.0) com validação (try/except + while para inválidas).
# Exiba: maior nota, menor nota, média, quantidade acima da média e
# classificação (Aprovado ≥ 7.0, Recuperação ≥ 5.0, Reprovado).
# Explique em comentários por que escolheu for ou while em cada parte.

# ── Sua solução abaixo ──────────────────────────────────────────────────────


notas = []

# Usei for pois sabia exatamente quantas notas precisava ler 
for i in range(10):

    # Usei while pois não sei quantas vezes o usuário vai tentar inserir uma nota válida
    while True:
        try:
            nota = float(input(f"Digite a nota {i+1} (0.0 - 10.0): "))
            if nota >= 0.0 and nota <= 10.0:
                #adiciona a nota na lista
                notas.append(nota)
                break
            else:
                print("Nota inválida. Digite um valor entre 0.0 e 10.0.")
        except ValueError:
            print("Entrada inválida. Por favor, digite um número.")


# Se existirem notas, segue com o codigo
if notas:
    maior_nota = max(notas) # Pegando a maior nota do vetor
    menor_nota = min(notas) # Pegando a menor nota do vetor
    media = sum(notas) / len(notas)
    acima_da_media = sum(1 for nota in notas if nota > media)

    print(f"\nResultados:")
    print(f"Maior nota: {maior_nota}")
    print(f"Menor nota: {menor_nota}")
    print(f"Média: {media:.2f}")
    print(f"Quantidade de alunos com nota acima da média: {acima_da_media}")
    print()
    
    # Classificação dos alunos

    #usei for para percorrer a lista e exibir cada classeficação de cada aluno
    for i, nota in enumerate(notas, start=1):
        if nota >= 7.0:
            classificacao = "Aprovado"
        elif nota >= 5.0:
            classificacao = "Recuperação"
        else:
            classificacao = "Reprovado"
        print(f"Aluno {i}: {nota} - {classificacao}")