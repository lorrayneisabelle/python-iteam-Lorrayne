# Lista 01 — Questão 06: Validador de Senha
# Aluno: Lorrayne Isabelle Paz de Oliveira
# Data:  22/05/2026

# ── Enunciado ───────────────────────────────────────────────────────────────
# Escreva um programa que solicite uma senha em loop até que atenda TODOS:
#   1. Mínimo 8 caracteres.
#   2. Pelo menos um dígito (use .isdigit() em cada caractere).
#   3. Pelo menos uma letra maiúscula.
# Para cada tentativa inválida, informe qual critério não foi atendido.
# Ao aceitar: 'Senha válida após X tentativa(s).'

# ── Sua solução abaixo ──────────────────────────────────────────────────────

tentativas = 0
while True:
    senha = input("\nDigite uma senha: ")
    tentativas += 1
    
    # Variáveis para validar se cada critério foi atendido
    tamanho_valido = False
    tem_digito = False
    tem_maiuscula = False



    # Valida se tem menos de 8 caracteres
    if len(senha) >= 8:
        tamanho_valido = True
    else:   
        print("A senha deve ter no mínimo 8 caracteres.")
    

    # Valida se tem pelo menos um dígito
    for caractere in senha:
        if caractere.isdigit():
            tem_digito = True
            break
            
    if not tem_digito:
        print("A senha deve conter pelo menos um dígito.")




    # Valida se tem pelo menos uma letra maiúscula
    for caractere in senha:
        if caractere.isupper():
            tem_maiuscula = True
            break
    
    if not tem_maiuscula:
        print("A senha deve conter pelo menos uma letra maiúscula.")

    

    # Se atender todos os critérios, sai do loop
    if tem_digito and tem_maiuscula:

        print(f"Senha válida após {tentativas} tentativa(s).")
        break