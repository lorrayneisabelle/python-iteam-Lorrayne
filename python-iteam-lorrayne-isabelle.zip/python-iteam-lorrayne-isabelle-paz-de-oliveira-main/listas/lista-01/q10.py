# Lista 01 — Questão 10: Análise Crítica de Código
# Aluno: Lorrayne Isabelle Paz de Oliveira
# Data:  22/05/2026

# ── Enunciado ───────────────────────────────────────────────────────────────
# Em q10.py: reescreva a função corrigindo os 3 problemas encontrados.
# 
#   def processar_alunos(alunos=[]):
#       aprovados = []
#       for i in range(len(alunos)):
#           if alunos[i]['nota'] >= 7.0:
#               aprovados = aprovados + [alunos[i]['nome']]
#       print(aprovados)
# 
# Em q10_resposta.txt: identifique cada problema e explique por que é um problema.
# Dica: há um problema em: (1) definição da função, (2) como o loop é escrito, (3) como a lista é construída.

# ── Sua solução abaixo ──────────────────────────────────────────────────────


def processar_alunos(alunos):  # 1º: Não é interessante usar uma lista como valor padrão pois ela pode ser alterada e er resultados imprevisíveis, melhor usar tupla
    aprovados = []
    for aluno in alunos:  # 2º: Usar for direto na lista é mais legível do que usar um loop com índice
        if aluno['nota'] >= 7.0:
            aprovados.append(aluno['nome'])  # 3º: Usar append é mais eficiente do que criar uma nova lista a cada iteração
    print(aprovados)